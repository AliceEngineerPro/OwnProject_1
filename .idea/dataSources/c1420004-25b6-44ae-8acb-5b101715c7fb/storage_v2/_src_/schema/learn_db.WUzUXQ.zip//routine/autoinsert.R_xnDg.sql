create
    definer = root@localhost procedure autoinsert()
begin
    declare i int default 1;
    while (i<500000)do
        insert into tb_1 value (i,'段博') ;
        set i=i+1 ;
        end while ;
end;

