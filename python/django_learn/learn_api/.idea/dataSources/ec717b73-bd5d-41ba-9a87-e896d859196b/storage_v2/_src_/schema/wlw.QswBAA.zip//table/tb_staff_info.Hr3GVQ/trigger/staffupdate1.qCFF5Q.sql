create definer = root@localhost trigger staffUpdate1
    before update
    on tb_staff_info
    for each row
begin



if 
old.`code`<>new.`code`
then
insert into tb_record_info(`type`,contactId,word,oldValue,newValue) 
 values('2',old.`id`,'code',old.`code`,new.`code`);
end if;


if 
old.`telephone`<>new.`telephone`
then
insert into tb_record_info(`type`,contactId,word,oldValue,newValue) 
 values('2',old.`id`,'telephone',old.`telephone`,new.`telephone`);
end if;


set @deptCodeOld = (SELECT deptName FROM sys_department WHERE `code` = old.`deptCode`);
set @deptCodeNew = (SELECT deptName FROM sys_department WHERE `code` = new.`deptCode`);
if 
old.`deptCode`<>new.`deptCode`
then
insert into tb_record_info(`type`,contactId,word,oldValue,newValue) 
 values('2',old.`id`,'deptname',@deptCodeOld,@deptCodeNew);
end if;


set @staffIdOld = (SELECT `name` FROM tb_storage_info WHERE id =  old.`storageId`);
set @staffIdNew = (SELECT `name` FROM tb_storage_info WHERE id =  new.`storageId`);
if 
old.`storageId`<>new.`storageId`
then
insert into tb_record_info(`type`,contactId,word,oldValue,newValue) 
 values('2',old.`id`,'name',@staffIdOld,@staffIdNew);
end if;


set @stafftypeOld  = (SELECT `name` FROM sys_config WHERE parentId = (SELECT id FROM sys_config WHERE configKey = 'staffType') AND `value` = old.stafftype);
set @stafftypeNew = (SELECT `name` FROM sys_config WHERE parentId = (SELECT id FROM sys_config WHERE configKey = 'staffType') AND `value` = new.stafftype);
if 
@stafftypeOld<>@stafftypeNew
then
insert into tb_record_info(`type`,contactId,word,oldValue,newValue) 
 values('2',old.`id`,'stafftype',@stafftypeOld,@stafftypeNew);
end if;






end;

