create view temp_alert_storage as
select `wlw`.`tb_ammo_info`.`storageId` AS `storageId`
from `wlw`.`tb_ammo_info`
where (`wlw`.`tb_ammo_info`.`storageState` between 2 and 6)
group by `wlw`.`tb_ammo_info`.`storageId`;

-- comment on column temp_alert_storage.storageId not supported: 所属仓库

